# -------------------------------------------------------
#
#
#
#
#
# -------------------------------------------------------

# ------------ imports
import board
import time
from utilities import Notification
from digitalio import DigitalInOut, Direction

# ------------ parametres ----------
broche_led1 = board.D6
broche_led2 = board.D9
broche_led3 = board.D10
# -------------------------------------------------------

# ------------- setup
# configuration de la sortie de la led
led1 = DigitalInOut(broche_led1)
led1.direction = Direction.OUTPUT  # c'est une sortie
led2 = DigitalInOut(broche_led2)
led2.direction = Direction.OUTPUT  # c'est une sortie
led3 = DigitalInOut(broche_led3)
led3.direction = Direction.OUTPUT  # c'est une sortie
# config des notifications
notif = Notification()
# show logo at startup
notif.oled_logo('media/logo_stex.bin')
time.sleep(5)

# -------------- boucle (loop)
while True:
    # feux rouge
    led1.value = True
    led2.value = False
    led3.value = False
    notif.notify(text="Led Rouge")
    time.sleep(2)
    # feux vert
    led1.value = False
    led2.value = False
    led3.value = True
    notif.notify(text="Led Verte")
    time.sleep(3)
    # feux orange
    led1.value = False
    led2.value = True
    led3.value = False
    notif.notify(text="Led Jaune")
    time.sleep(1)
